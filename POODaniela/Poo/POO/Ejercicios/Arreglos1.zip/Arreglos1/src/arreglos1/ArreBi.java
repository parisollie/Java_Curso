/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arreglos1;

public class ArreBi {

    public static void main(String[] args) {

        int Arre[][]=new int[5][3];
        
        
        for(int i=0;i<Arre.length;i++)
            for(int j=0;j<Arre[i].length;j++)
                Arre[i][j]=i+j*i+1;
    
        for(int i=0;i<Arre.length;i++){
            
                System.out.println();
            for(int j=0;j<Arre[i].length;j++)
                System.out.printf("\t%d",Arre[i][j]);
    
    }  
}
}