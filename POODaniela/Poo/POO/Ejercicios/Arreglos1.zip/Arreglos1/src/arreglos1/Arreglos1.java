/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arreglos1;

public class Arreglos1 {

    public static void main(String[] args) {

        double Arre[] = new double[10];
       
        for(int i=0;i<Arre.length;i++){
            Arre[i]=i*2;
            System.out.printf("\nA[%d]=%f",i,Arre[i]);
        }
    
}
}