import java.util.Scanner;
package compleja;

/**
 *
 * @author victor
 */
public class Compleja {

double real,im;
    
    public static void main(String[] args) {

        Compleja C=new Compleja();
        Compleja D=new Compleja();
        
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Dame la parte real del numero 1");
        C.real=sc.nextDouble();
        System.out.println("Dame la parte imaginaria del numero 1");
        C.im=sc.nextDouble();
        System.out.println("Dame la parte real del numero 2");
        D.real=sc.nextDouble();
        System.out.println("Dame la parte imaginaria del numero 2");
        D.im=sc.nextDouble();
        sumar(C,D);
        
    }
    public static double sumar(Compleja X, Compleja Y){
        
        
        System.out.printf("\nLa suma es %f + %f i",X.real+Y.real,X.im+Y.im);
        
        return 0;
    }
}
