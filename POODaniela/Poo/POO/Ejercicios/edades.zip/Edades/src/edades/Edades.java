
package edades;

import java.util.Scanner;
public class Edades {

    public static void main(String[] args) throws EdadesExcepcion {
        Scanner sc=new Scanner(System.in);
        System.out.println("Ingresa tu edad");
        int edad=sc.nextInt();
        final int Edadmax=100;
        
             if (edad<Edadmax) {
                 System.out.println("Bienvenido");
             }
             else {
                 throw new EdadesExcepcion("Edad no permitida");
             }
               
           
    
         
         
    }
    
}
