package edades;
public class EdadesExcepcion extends Exception {
    public EdadesExcepcion(String mensaje){
        
    super(mensaje);
    }
}
