/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Monitor;

/**
 *
 * @author Jessie
 */
public class Monitor implements Runnable{
static int g=0;
private Monitor h1;
private Monitor h2;
private Monitor h3;
private Monitor h4;
private Monitor h5;


private boolean usoMem = false; // acceso semaforo
private boolean usoGraf = false; // acceso semaforo
private boolean usoReloj = false; // acceso semaforo
private boolean usoEs = false; // acceso semaforo
private boolean usoCom = false; // acceso semaforo

//************************************************************

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        for(int i=0;i<25;i++){//creación de hilos
            Monitor h1 = new Monitor();
            Thread thread = new Thread (h1, "Hilo número 1");
            thread.start();

            Monitor h2 = new Monitor();
            Thread thread1 = new Thread (h2, "Hilo número 2");
            thread1.start();
        
            Monitor h3 = new Monitor();
            Thread thread2 = new Thread (h3, "Hilo número 3");
            thread2.start();

            Monitor h4 = new Monitor();
            Thread thread3 = new Thread (h4, "Hilo número 4");
            thread3.start();

            Monitor h5 = new Monitor();
            Thread thread4 = new Thread (h5, "Hilo número 5");
            thread4.start();

            }
    
            }
    
    public void run(){
        //Estos métodos los realizaran los hilos
        almacenar();
        graficar();
        reloj();
        entrarsalir();
        comunicar();
        
        
}
    
    public synchronized int almacenar()
{
    
while (usoMem)
{
try
{
wait(); // Los threads  esperan aquí hasta que ser notificados.
}
catch (Exception e) { }
}
// los demas hilos   tienen acceso al procesador
for(int i=0;i<100;i++)
System.out.printf("\n%s Almacenando datos en disco duro %d de 100",Thread.currentThread().getName(),i);
 usoMem = true;
 usoGraf=false;
 usoReloj=false;
 usoEs=false;
 usoCom=false;
notifyAll();
return 1;
} // end almacenar
//************************************************************

public synchronized int graficar()
{
    
while (usoGraf)
{
try
{
wait(); // Los threads  esperan aquí hasta que ser notificados.
}
catch (Exception e) { }
}
// los demas hilos   tienen acceso al procesador

for(int i=0;i<100;i++)
System.out.printf("\n%s Visualizando gráficos '%d de 100",Thread.currentThread().getName(),i);
 usoMem = false;
 usoGraf=true;
 usoReloj=false;
 usoEs=false;
 usoCom=false;
 notifyAll();
return 1;
}

public synchronized int reloj()
{
    
while (usoReloj)
{
try
{
wait(); // Los threads  esperan aquí hasta que ser notificados.
}
catch (Exception e) { }
}
// los demas hilos   tienen acceso al procesador

for(int i=0;i<100;i++)
System.out.printf("\n%s Atendiendo el reloj %d de 100",Thread.currentThread().getName(),i);
usoMem = false;
 usoGraf=false;
 usoReloj=true;
 usoEs=false;
 usoCom=false;
 notifyAll();
return 1;
} 

public synchronized int entrarsalir()
{
    
while (usoEs)
{
try
{
wait(); // Los threads  esperan aquí hasta que ser notificados.
}
catch (Exception e) { }
}
// los demas hilos   tienen acceso al procesador

for(int i=0;i<100;i++)
System.out.printf("\n%s Recibiendo y enviando datos %d de 100",Thread.currentThread().getName(),i);
 usoMem = false;
 usoGraf=false;
 usoReloj=false;
 usoEs=true;
 usoCom=false;
 notifyAll();
return 1;
} 

public synchronized int comunicar()
{
    
while (usoMem&&!usoGraf&&!usoReloj&&!usoEs)
{
try
{
wait(); // Los threads  esperan aquí hasta que ser notificados.
}
catch (Exception e) { }
}
// los demas hilos   tienen acceso al procesador

for(int i=0;i<100;i++)
System.out.printf("\n%s Comunicando con el mundo exterior a través de la DEEP WEB %d de 100",Thread.currentThread().getName(),i);
 usoMem = false;
 usoGraf=false;
 usoReloj=false;
 usoEs=false;
 usoCom=true;
 notifyAll();
return 1;
} 
} 

