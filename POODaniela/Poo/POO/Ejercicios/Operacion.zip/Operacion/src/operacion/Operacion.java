package operacion;

import java.util.Scanner;

public class Operacion {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num1,num2;
            
            System.out.println("DIVISION");
                System.out.println("Ingresa el primer numero:");
            try{
                try{
                num1=sc.nextInt();
                System.out.println("Ingresa el segundo numero:");
                num2=sc.nextInt();
                System.out.println("El resultado de la division es:"+num1/num2);
                }
                catch(Exception e){
                    System.out.println("Error Error");
                }
                num1=sc.nextInt();
                System.out.println("Ingresa el segundo numero:");
                num2=sc.nextInt();
                System.out.println("El resultado de la division es:"+num1/num2);
            }
            catch(java.lang.ArithmeticException e){
                System.out.println("La division entre 0 no se puede ejecutar");
            }
            catch(java.util.InputMismatchException e){
                System.out.println("El dato ingresado no es un entero");
            }
            finally{
                System.out.println("Proceso terminado");
            }
    }
    
}