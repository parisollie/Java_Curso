
package pruebaassert;

import java.util.Scanner;

/**
 *
 * @author victor
 */
public class PruebaAssert {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ecribe un numer entre 0 y 10");
        int numero =sc.nextInt();
        
        assert (numero >=0 && numero<=10): "numero incorrecto " + numero;
        System.out.printf("Escriiste %d\n ", numero);
        assert ((numero%2) != 0):"Numero no entero"+numero;
    }
    
}
