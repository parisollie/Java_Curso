/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poli;

/**
 *
 * @author victor
 */
public class Prueba {

    public static void main(String[] args) {

        Persona P=new Persona();
        Cuates C1=new Cuates();
        CuatesFI CF=new CuatesFI("afedo",345673,78.23);
        Cuates C2=new Cuates("María",19,60.23);
        Cuates C3=new Cuates("Sebastian",20,65.23,"orfi",456781,6.76);
        
        System.out.printf("\n%s tiene %d años y pesa %f kilos",C1. nombre,C2.edad,C2.peso);
        System.out.printf("\n%s alias el %s tiene %d años y pesa %f kilos su cel es %d y alcanza un promedio de %f",C3.nombre,C3.apodo,C3.edad,C3.peso,C3.NoCel,C3.promedio);
        System.out.printf("\nel cel de %s es %d y debe %f pesos",CF.nombre,CF.NoCel,CF.multa);
        // TODO code application logic here
    }
    
}
