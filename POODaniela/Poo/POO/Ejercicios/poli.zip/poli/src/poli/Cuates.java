/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poli;

import java.util.Scanner;

/**
 *
 * @author victor
 */
public class Cuates extends Persona{

   String apodo;
   int NoCel;
   double promedio;
   public Cuates(){
       Scanner sc=new Scanner(System.in);
       System.out.println("Se ha creado un objeto Cuates sin inicializar");
       System.out.println("Dame el nombre del cuate: ");
       nombre=sc.next();
       
   }
   public Cuates(String nom, int ed, double pes){
   nombre=nom;
   edad=ed;
   peso=pes;
       System.out.println("Se ha creado un objeto cuates inicializando los atributos Persona");
   
   }
   
   public Cuates(String nom, int ed, double pes,String ap,int NC,double prom){
   this.nombre=nom;
   edad=ed;
   peso=pes;
   apodo=ap;
   NoCel=NC;
   promedio=prom;
    
}

   public void estudiar(){
       System.out.println(nombre+"esta estudiano");
   }
   
   public void comer(){
   System.out.println(nombre+"esta comiendo");
       
   }
    
}
