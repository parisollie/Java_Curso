/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poli;

/**
 *
 * @author victor
 */
public class CuatesFI extends Cuates{
    String Carrera;
    int NoCuenta;
    double multa;
    
    public CuatesFI(String nom, int NC,double mul){
        nombre=nom;
        NoCel=NC;
        multa=mul;
    }
    
    
}
