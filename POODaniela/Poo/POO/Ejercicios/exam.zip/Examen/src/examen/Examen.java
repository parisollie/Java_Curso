/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examen;

/**
 *
 * @author victor
 */
public class Examen {

int Arre[]=new int[25];
Examen A=new Examen();
    public static void main(String[] args) {

        Examen E=new Examen();
        for(int i=0;i<25;i++)
            E.Arre[i]=i*i+1;
        
        System.out.println("La suma es "+E.sumar());
        
    }
    public static void imprimir(int A[]){
    for(int i=0;i<A.length;i++)
            System.out.println(A[i]);
    }
    public int sumar(){
        int s=0;
        for(int i=0;i<Arre.length;i++)
            s=s+Arre[i];
        return s;
    }
    
}
