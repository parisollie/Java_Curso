
package metodos;
import java.util.Arrays;

 public class ArrayManipulacion{
     public static void main( String[] args ){
         
         // ordena el arreglo en orgen ascendente
         double[] doubleArray = {8.4, 9.3,0.2, 7.9,3.4};
         Arrays.sort(doubleArray);
         System.out.printf("\ndoubleArray: ");
         
         for (double valor : doubleArray)
             System.out.printf("%.1f ", valor);
         
         // fill llena el arreglo con 7s
         int[] filledIntArray = new int[ 10 ]; 
         Arrays.fill(filledIntArray, 7);
         imprimeArray( filledIntArray, "filledIntArray" ); 
         
         // copy array intArray into array intArrayCopy 
         int[] intArray = { 1, 2, 3, 4, 5, 6 };
         int[] intArrayCopy = new int[ intArray.length ];
         System.arraycopy(intArray, 0, intArrayCopy, 0, intArray.length);
         imprimeArray( intArray, "intArray" );
         imprimeArray( intArrayCopy, "intArrayCopy" );
         
         // compare intArray and intArrayCopy for equality
         boolean b = Arrays.equals(intArray, intArrayCopy);
         System.out.printf( "\n\nintArray %s intArrayCopy\n", (b?"==" : "!=" ) ); 
         
         // compare intArray and filledIntArray for equality
         b = Arrays.equals(intArray, filledIntArray);
         System.out.printf( "intArray %s filledIntArray\n", (b?"==" : "!=" ) ); 
         
         // search intArray for the value 5
         int posicion = Arrays.binarySearch(intArray, 5);
         if(posicion >= 0)
             System.out.printf("Se encontro 5 en la posicion: %d en intArray\n", posicion);
         else
             System.out.println("5 no fue encontrado en intArray");
         
         // search busca intArray for the value 8763
         posicion = Arrays.binarySearch(intArray, 8763);
         if ( posicion >= 0 )
             System.out.printf("se encontro 8763 en la posicion: %d en intArray\n", posicion );
         else
             System.out.println( "8763 no fue encontrado en intArray" );
     } // fin main 
         
     public static void imprimeArray(int[] array, String descripcion){
         System.out.printf("\n%s: ", descripcion);
         
         for(int valor : array)
             System.out.printf("%d ", valor);
    }           
}
