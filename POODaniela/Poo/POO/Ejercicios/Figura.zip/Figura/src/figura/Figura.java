/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package figura;

/**
 *
 * @author victor
 */
import java.util.Scanner;
abstract class Figura {
    private String nombre;
    /**
     * @param args the command line arguments
     */
    public Figura(String nom){
        nombre=nom;   
    }
    public String getNombre(){
        return nombre;
    }
    public abstract double damePerimetro();
    public abstract double dameArea();
    
    public static void main(String[] args) {
        // TODO code application logic here
        int op;
        Scanner sc = new Scanner(System.in);
        Figura figuras[] = new Figura[2];
        System.out.println("Elige una figura: ");
        System.out.println("1. Cuadrado \n2. Triangulo \n3. Salir");
        do{
          System.out.println("Elige una figura: ");
          System.out.println("1. Cuadrado \n2. Triangulo \n3. Salir");
          op = sc.nextInt();
          switch(op){
              case 1:
                  figuras[0] = new Cuadrado("Cuadrado");
                  System.out.println("Elegiste "+figuras[0].getNombre());
                  System.out.println("El area es: "+figuras[0].dameArea());
                  System.out.println("El perimetro es: "+figuras[0].damePerimetro());
                  break;
              case 2:
                  figuras[1] = new Triangulo("Triangulo");
                  System.out.println("Elegiste "+figuras[1].getNombre());
                  System.out.println("El area es: "+figuras[1].dameArea());
                  System.out.println("El perimetro es: "+figuras[1].damePerimetro());
                  break;
              case 3:
                  break;
              default:
                  System.out.println("Elige bien imbe...");
          }
              
        }while(op != 3);
    }
    
}
class Triangulo extends Figura{
    Scanner sc = new Scanner(System.in);
    public Triangulo(String nom){
        super(nom);
    }
    public double damePerimetro(){
        double perimetro = 0.0;
        double lado[];
        lado = new double[3];
        System.out.println("Calculo del perimetro: ");
        for(int i = 0; i<=2;i++){
           System.out.println("Dame el lado "+(i+1)+":");
           lado[i] = sc.nextDouble();
           perimetro += lado[i];
        }
        return perimetro;
    }
    public double dameArea(){
        double area;
        double base, altura;
        System.out.println("Calculo del area: ");
        System.out.println("Dame la base: ");
        base = sc.nextDouble();
        System.out.println("Dame la altura: ");
        altura = sc.nextDouble();
        area = (base*altura)/2;
        return area;
    }
}
class Cuadrado extends Figura{
    Scanner sc = new Scanner(System.in);
    public Cuadrado(String nom){
        super(nom);
    }
    public double damePerimetro(){
        double perimetro = 0.0;
        double lado;
        System.out.println("Calculo del perimetro: ");
        System.out.println("Dame el lado: ");
        lado = sc.nextDouble();
        perimetro = lado*4;
        return perimetro;
    }
    public double dameArea(){
        double area;
        double lado;
        System.out.println("Calculo del area: ");
        System.out.println("Dame el valor de los lados: ");
        lado = sc.nextDouble();
        area = lado*lado;
        return area;
    }
    
}

