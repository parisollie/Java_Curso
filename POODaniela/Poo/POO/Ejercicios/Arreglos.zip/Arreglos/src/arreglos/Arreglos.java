
package arreglos;
import java.util.Scanner;

/**
 *
 * @author victor
 */
public class Arreglos {

int A[]=new int[10];

    public static void main(String[] args) {
    int B[]=new int[10];

    Arreglos Z=new Arreglos();
    Scanner sc=new Scanner(System.in);
    
    Z.llenar();
    llenar(B);
    imprimir(Z.A);
    System.out.println();
    imprimir(B);
// TODO code application logic here
    }
    public void llenar(){
        for(int i=0;i<A.length;i++)
            A[i]=i+1;
    }
      public static void llenar(int C[]){
        for(int i=0;i<C.length;i++)
            C[i]=i+1;
    }
      public static void imprimir(int C[]){
          for(int i=0;i<C.length;i++)
              System.out.printf("\nA[%d]=%d", i,C[i]);
      }
}
