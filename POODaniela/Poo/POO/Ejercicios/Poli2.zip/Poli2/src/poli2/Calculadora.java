/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poli2;

import java.util.Scanner;

/**
 *
 * @author victor
 */
public class Calculadora {
    double x,y;
    
    

    public static void main(String[] args) {
    
    Scanner sc=new Scanner(System.in);
    Calculadora C=new Calculadora();
        System.out.println("Dame un numero: ");
        C.x=sc.nextDouble();
        System.out.println("Dame otro numero: ");
        C.y=sc.nextDouble();
        
        System.out.printf("%d",C.sumar());
        System.out.printf("%f",sumar(C.x,C.y));
        System.out.printf("%f",sumar(C));
        
        }
        public int sumar(){
        return (int)(x+y);
        }
        public static double  sumar(double a, double b){
        return b+a;
        }
        public static double  sumar(Calculadora C){
        
            return C.x+C.y;
        }
}
