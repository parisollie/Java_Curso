package excepciones;
import java.util.*;
import java.lang.Math;
public class Biseccion {
static double[] coef = new double[100];   
    public static double f(double x){
        Scanner sc=new Scanner(System.in);
        System.out.println("Dame el grado mayor  de la ecuacion");
        int grado=sc.nextInt();
        double suma=0;
        for(int i=0;i<grado;i++){
             suma+=Math.pow(x,i)*coef[i];
        }
        return suma;    
    }
    public static double[] llenarpolinomio(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Dame el grado mayor  de la ecuacion");
        int grado=sc.nextInt();
        for(int i=0;i<grado;i++){
            System.out.println("Dame el coeficiente de grado "+i);
            coef[i]=sc.nextDouble();
        }
        return coef;
    }
            
    public static double[] getInterval() throws InvalidIntervalException{
        Scanner sc = new Scanner(System.in);
        double[] values = new double[2];
        double a=sc.nextDouble();
        double b=sc.nextDouble();
        values[0]=a;
        values[1]=b;
        if( f(a)*f(b) < 0 ){
            return values;
        }else{
            throw new InvalidIntervalException();
        }
    }
    
    public static double getRoot(double a, double b){
        double middle=(a+b)/2;
        double error=0.000000005;
        
        while( f(middle) > error || f(middle) < (-1)*error ){
            if( f(middle)*f(a) < 0){
                b=middle;
                middle=(a+b)/2;
            } else{
                a=middle;
                middle=(a+b)/2;
            }
        }
        return middle;
    }
}
