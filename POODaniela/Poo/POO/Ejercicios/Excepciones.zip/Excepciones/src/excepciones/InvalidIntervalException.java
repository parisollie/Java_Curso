package excepciones;

public class InvalidIntervalException extends Exception{
    InvalidIntervalException(){
        super();
    }
    
    InvalidIntervalException(String message){
        super(message);
        System.out.println(message);
        
    }
    
    InvalidIntervalException(String message, Throwable thr){
        super(message, thr);
    }
    
}
