package excepciones;

public class Prueba {
double coef[];
    public static void main(String[] args) {
        Biseccion B=new Biseccion();
        try{
            B.llenarpolinomio();
        double[] values=Biseccion.getInterval();
        double a=values[0];
        double b=values[1];
        double root=Biseccion.getRoot(a,b);
        System.out.printf("La raiz entre %f y %f es: %f\n", a, b, root);
        
        }catch(InvalidIntervalException e){
            e.printStackTrace();
            System.out.println("Ingresa un intervalo válido");
            main(new String[0]);
        }
        
    }
    
}
