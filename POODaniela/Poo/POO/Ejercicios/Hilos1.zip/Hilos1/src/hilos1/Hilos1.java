/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hilos1;


public class Hilos1 extends Thread{

    static double x[]=new double[500];
    static double sum,sum1,sum2,sum3,sum4,sum5,sum6;
    public Hilos1(String str){
        super(str);
    }
    
    public void run(){
        
        if(getName().compareTo("uno")==0)
            for(int i=0;i<101;i++)
                sum1+=x[i];
        
        else if(getName().compareTo("dos")==0)
            for(int i=101;i<201;i++)
                sum2+=x[i];
        else if(getName().compareTo("tres")==0)
            for(int i=201;i<301;i++)
                sum3+=x[i];
        else if(getName().compareTo("cuatro")==0)
            for(int i=301;i<401;i++)
                sum4+=x[i];
        else if(getName().compareTo("cinco")==0)
            for(int i=401;i<500;i++)
                sum5+=x[i];
        else if(getName().compareTo("seis")==0)
        {    sum6=sum1+sum2+sum3+sum4+sum5;
        System.out.println("La suma es "+sum6);
        try{
            Thread.sleep(10000);
        }
        catch(InterruptedException ex){}
            System.out.println("La suma es "+sum6);
        }
    }
    public static void main(String[] args) {

        for(int i=0;i<500;i++){
            x[i]=i;
            sum+=i;
        }
Hilos1 h1=new Hilos1("uno");
h1.start();        
Hilos1 h2=new Hilos1("dos");
h2.start();        
Hilos1 h3=new Hilos1("tres");
h3.start();        
Hilos1 h4=new Hilos1("cuatro");
h4.start();        
Hilos1 h5=new Hilos1("cinco");
h5.start();        
Hilos1 h6=new Hilos1("seis");
h6.start();        


h1.setPriority(Thread.MAX_PRIORITY);  
h2.setPriority(Thread.MAX_PRIORITY);  
h3.setPriority(Thread.MAX_PRIORITY);  
h4.setPriority(Thread.MAX_PRIORITY);  
h5.setPriority(Thread.MAX_PRIORITY);  
h6.setPriority(Thread.MIN_PRIORITY);  
        
    }
    
}
