/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase73;

import java.util.Scanner;

/**
 *
 * @author victor
 */
public class Cuates {
    String nombre;
    int edad;
    double promedio;
    static double acumulador;
    int nocuenta;
    static double suma;
public static void main(String args[]){
   Cuates cuate1 = new Cuates();
   Cuates cuates2= new Cuates();
   Cuates andresito=new Cuates();
   
   Cuates cuate5 = new Cuates();
   Cuates cuates6= new Cuates();
   Cuates cuates7=new Cuates();
   
   System.out.println(cuate1.nombre+" "+cuate1.edad+" "+cuate1.nocuenta+" "+cuate1.promedio);
   System.out.println(cuates2.nombre+" "+cuates2.edad+" "+cuates2.nocuenta+" "+cuates2.promedio);
   System.out.println(andresito.nombre+" "+andresito.edad+" "+andresito.nocuenta+" "+andresito.promedio);
   System.out.println(cuate5.nombre+" "+cuate5.edad+" "+cuate5.nocuenta+" "+cuate5.promedio);
   System.out.println(cuates6.nombre+" "+cuates6.edad+" "+cuates6.nocuenta+" "+cuates6.promedio);
   System.out.println(cuates7.nombre+" "+cuates7.edad+" "+cuates7.nocuenta+" "+cuates7.promedio);
   
   System.out.println("El promedio de los cuates es:\t"+(suma/acumulador));
}
public Cuates(){
   
    Scanner sc=new Scanner(System.in);
    System.out.println("Dame tu nombre ");
    nombre=sc.nextLine();
    System.out.println("Dame tu edad ");
    edad=sc.nextInt();
    System.out.println("Dame tu promedio ");
    promedio=sc.nextDouble();
    suma=suma+promedio;
    System.out.println("Dame tu Numero de cuenta ");
    nocuenta=sc.nextInt();
    acumulador++;
    
          
}
}