/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase73;

/**
 *
 * @author victor
 */
public class Clase73 {
    String nombre;
    int edad;
    double promedio;
    int nocuenta;
    static int contador;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Clase73 clase = new Clase73("Comoquiera", 37, 10.0);
        Clase73 clase1 = new Clase73("Pepito",12,9.7);
        Clase73 clase2 = new Clase73("Juan", 20, 8.6, 4567894);
        
        System.out.println("Se crearon"+" "+contador+" "+"objetos:");
        
    }
    public Clase73(String nom, int ed, double prom){
        nombre = nom;
        edad = ed;
        promedio = prom;
        contador=contador+1;
        System.out.println("Se ha creado un objeto");

    }
    
    public Clase73(String nom, int ed, double prom, int cuen){
        nombre = nom;
        edad = ed;
        promedio = prom;
        nocuenta = cuen;
        contador=contador+1;
        System.out.println("Se ha creado un objeto");

    }
    
}
