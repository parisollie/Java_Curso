/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionarchivos;
import java.io.*;


/**
 *
 * @author Jessie
 */
public class GestionA {//En esta clase se crean los objetos que permiten el flujo de datos a los archivos
    FileInputStream entrada;
    FileOutputStream salida;
    File archivo;
    
    public GestionA(){
        
    }
    
    /*Abrir un archivo de texto*/
    public String AbrirATexto(File archivo){
        String contenido="";
        try {
            entrada = new FileInputStream(archivo);//entrada es un buffer de lectura
            int ascci;
            while((ascci = entrada.read())!= -1){//Lee el archivo hasta el final del archivo
                char carcater = (char)ascci;
                contenido += carcater;//coloca en el area de texto un caracter a la vez en el archivo
            }
        } catch (Exception e) {
        }
        return contenido;
    }
    
    /*Guardar archivo de texto*/
    public String GuardarATexto(File archivo, String contenido){
        String respuesta=null;
        try {
            salida = new FileOutputStream(archivo);
            byte[] bytesTxt = contenido.getBytes();//Toma lo del area de texto 
            salida.write(bytesTxt);//Escribe en el archivo 
            respuesta = "Se guardo con exito el archivo";
           
        } catch (Exception e) {
        }
        return respuesta;
    }
    
    public String eliminarArchivo(String archivo){//Borra un archivo
String respuesta="Archivo en uso o no existe";
try{
     File Arch = new File(archivo);
     if(Arch.delete())
          respuesta= "archivo eliminado";
    
     }
 catch (Exception e) {
        }
return respuesta;
    }                    

    
     public String[] ListarArchivos(String archivo){//Lista los archivos y directorios
         String Lista[]=new String[100];
         try{
     File Arch = new File(archivo);
     Lista= Arch.list();
    
     }
 catch (Exception e) {
        }
return Lista;
    }                    

       public String crearDirectorio(String archivo){//crea un nuevo directorio
           String respuesta=null;
           try{
     File Arch = new File(archivo);
     if(Arch.mkdir())
          respuesta= "Directorio creado";
           }
     
 catch (Exception e) {
        }
    return respuesta;
}

}
