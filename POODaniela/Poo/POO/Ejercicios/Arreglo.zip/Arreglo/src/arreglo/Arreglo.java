/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arreglo;

import java.util.Scanner;

/**
 *
 * @author victor
 */
public class Arreglo {

int A[];

    public static void main(String[] args) {

        int n;
        Arreglo M=new Arreglo();
        System.out.println("De que tamaño es el arreglo: ");
        Scanner sc=new Scanner(System.in);
        n=sc.nextInt();
       M.A=new int[n];
        for(int i=0;i<n;i++)
            M.A[i]=i+3;
        
        for(int i=0;i<n;i++)
            System.out.println("A["+i+"]= "+M.A[i]);
    }
  
}
